// // 1-
// function salomBer() {
//     console.log("Salom Astrum");
// }

// salomBer();



// // 2-
// function salomBerIsm(ism) {
//     console.log("Salom, " + ism + "!");
// }

// let foydalanuvchiIsmi = prompt("Ismingizni kiriting:");
// salomBerIsm(foydalanuvchiIsmi);



// // 3-
// function kattasiniTop(son1, son2) {
//     if (son1 > son2) {
//         return son1;
//     } else {
//         return son2;
//     }
// }

// let son1 = parseFloat(prompt("Birinchi sonni kiriting:"));
// let son2 = parseFloat(prompt("Ikkinchi sonni kiriting:"));

// let kattaSon = kattasiniTop(son1, son2);
// console.log("Kattasi: " + kattaSon);



// // 4-
// function faktorial(son) {
//     if (son === 0 || son === 1) {
//         return 1;
//     } else {
//         return son * faktorial(son - 1);
//     }
// }

// let foydalanuvchiSon = parseInt(prompt("Faktorialini hisoblash uchun son kiriting:"));

// let natija = faktorial(foydalanuvchiSon);
// console.log(foydalanuvchiSon + " sonining faktoriali: " + natija);




// // 5-
// function kvadratHisobla(son) {
//     return son * son;
// }

// let foydalanuvchiSon = parseFloat(prompt("Kvadratini hisoblash uchun son kiriting:"));

// let natija = kvadratHisobla(foydalanuvchiSon);
// console.log(foydalanuvchiSon + " sonining kvadrati: " + natija);




// // 6-
// function kubHisobla(son) {
//     return son * son * son;
// }

// let foydalanuvchiSon = parseFloat(prompt("Kubini hisoblash uchun son kiriting:"));

// let natija = kubHisobla(foydalanuvchiSon);
// console.log(foydalanuvchiSon + " sonining kubi: " + natija);



// // 7-
// function engKattaSon(massiv) {
//     return Math.max(...massiv);
// }

// let sonlarMassivi = [2, 4, 5, 30, 54, 56, 23, 100, 0, 3, 6];

// let kattaSon = engKattaSon(sonlarMassivi);
// console.log("Eng katta son: " + kattaSon);



// // 8-
// function engUzunMatn(massiv) {
//     let engUzun = massiv[0]; // Birinchi elementni eng uzun deb olamiz
//     for (let i = 1; i < massiv.length; i++) {
//         if (massiv[i].length > engUzun.length) {
//             engUzun = massiv[i];
//         }
//     }
//     return engUzun;
// }

// let matnlarMassivi = ["Jasur", "Muhammad Yusuf", "Abdulla", "Mirzoavaz", "Beksulton"];

// let uzunMatn = engUzunMatn(matnlarMassivi);
// console.log("Eng uzun matn: " + uzunMatn);



// // 9-
// function engKichikSon(massiv) {
//     let engKichik = massiv[0]; 
//     for (let i = 1; i < massiv.length; i++) {
//         if (massiv[i] < engKichik) {
//             engKichik = massiv[i];
//         }
//     }
//     return engKichik;
// }

// let sonlarMassivi = [10, 23, -5, 44, 0, -12, 37];

// let kichikSon = engKichikSon(sonlarMassivi);
// console.log("Eng kichik son: " + kichikSon);



// // 10-
// function engQisqaMatn(massiv) {
//     let engQisqa = massiv[0]; 
//     for (let i = 1; i < massiv.length; i++) {
//         if (massiv[i].length < engQisqa.length) {
//             engQisqa = massiv[i];
//         }
//     }
//     return engQisqa;
// }

// let matnlarMassivi = ["Charos", "Muhabbat", "Aslzoda", "Madinabonu", "Bahoraxon"];

// let qisqaMatn = engQisqaMatn(matnlarMassivi);
// console.log("Eng qisqa matn: " + qisqaMatn);
