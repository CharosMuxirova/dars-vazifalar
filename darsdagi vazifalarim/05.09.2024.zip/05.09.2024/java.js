// // 6-

// function login(ism, parol) {
//     if (ism === "admin" && parol === "12345") {
//         console.log("Xush kelibsiz admin!");
//     } else {
//         console.log("Foydalanuvchi yoki parol xato!");
//     }
// }

// let ism = prompt("Ismingizni kiriting:");
// let parol = prompt("Parolingizni kiriting:");
// login(ism, parol);

// // 7
// function kabisaYiliTekshirish(yil) {
//     if ((yil % 4 === 0 && yil % 100 !== 0) || yil % 400 === 0) {
//         console.log(yil + " - kabisa yili.");
//     } else {
//         console.log(yil + " - kabisa yili emas.");
//     }
// }

// let yil = prompt("Yilni kiriting:");
// kabisaYiliTekshirish(parseInt(yil));


// // 8-

// function musbatTekshirish(son1, son2) {
//     if (son1 > 0 && son2 > 0) {
//         console.log("Ikkalasi ham musbat.");
//     } else {
//         console.log("Manfiy sonlar mavjud.");
//     }
// }

// let son1 = prompt("Birinchi sonni kiriting:");
// let son2 = prompt("Ikkinchi sonni kiriting:");
// musbatTekshirish(parseFloat(son1), parseFloat(son2));

// // 9-
// function raqamlarYigindisi(son) {
//     let yigindi = 0;
//     while (son) {
//         yigindi += son % 10;
//         son = Math.floor(son / 10);
//     }
//     return yigindi;
// }

// function juftTekshirish(son) {
//     let yigindi = raqamlarYigindisi(Math.abs(son)); 
//     if (son % 2 === 0 || yigindi % 2 === 0) {
//         console.log("Juft son.");
//     } else {
//         console.log("Juft emas.");
//     }
// }

// let son = prompt("Son kiriting:");
// juftTekshirish(parseInt(son));


// // 10-
// function karralikTekshirish(son) {
//     if (son % 3 === 0 && son % 7 === 0) {
//         console.log("3 va 7 ga karrali.");
//     } else if (son % 3 === 0) {
//         console.log("3 ga karrali.");
//     } else if (son % 7 === 0) {
//         console.log("7 ga karrali.");
//     } else {
//         console.log("3 va 7 ga karrali emas.");
//     }
// }
// let son = prompt("Musbat son kiriting:");
// karralikTekshirish(parseInt(son));


// // 11-
// function bahoAniqlash(ism, ball) {
//     if (ball >= 70 && ball <= 100) {
//         console.log(ism + " 5 baho oldi.");
//     } else if (ball >= 55 && ball < 70) {
//         console.log(ism + " 3 baho oldi.");
//     } else {
//         console.log(ism + " baho olishga yetmadi.");
//     }
// }
// let jamshidBall = 63;
// let shuxratBall = 71;
// let anvarBall = 92;

// bahoAniqlash("Jamshid", jamshidBall);
// bahoAniqlash("Shuxrat", shuxratBall);
// bahoAniqlash("Anvar", anvarBall);
