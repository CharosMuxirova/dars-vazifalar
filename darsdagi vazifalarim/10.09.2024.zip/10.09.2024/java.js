// // 1
// let mevalar = ["olma", "banan", "uzum", "anor", "shaftoli"];

// mevalar.forEach(function(meva) {
//     console.log(meva.toUpperCase());
// });


// // 2-
// function engKattaVaEngKichik(massiv) {
//     let engKichik = Math.min(...massiv);
//     let engKatta = Math.max(...massiv);
//     return { engKichik, engKatta };
// }

// let sonlarMassivi = [10, 23, -5, 44, 0, -12, 37];

// let natija = engKattaVaEngKichik(sonlarMassivi);
// console.log("Eng kichik son: " + natija.engKichik);
// console.log("Eng katta son: " + natija.engKatta);



// // 3-
// function juftSonlarYigindisi(massiv) {
//     let yigindi = 0;
//     massiv.forEach(function(son) {
//         if (son % 2 === 0) {
//             yigindi += son;
//         }
//     });
//     return yigindi;
// }

// let sonlarMassivi = [10, 23, -5, 44, 0, -12, 37];

// let yigindi = juftSonlarYigindisi(sonlarMassivi);
// console.log("Juft sonlar yig'indisi: " + yigindi);



// // 4
// function teskariTartibda(massiv) {
//     return massiv.slice().reverse(); // slice() yordamida yangi massiv yaratamiz
// }

// let sonlarMassivi = [10, 23, -5, 44, 0, -12, 37];

// let teskariMassiv = teskariTartibda(sonlarMassivi);
// console.log("Teskari tartibdagi massiv: " + teskariMassiv);



// // 5
// function faqatStringElementlar(massiv) {
//     return massiv.filter(function(element) {
//         return typeof element === 'string';
//     });
// }

// let aralashMassiv = ["salom", 2, true, "hi", "hello", "ok", null, 232];

// let stringElementlar = faqatStringElementlar(aralashMassiv);
// console.log("String elementlardan iborat yangi massiv: " + stringElementlar);



// // 6

// function ortachaArifmetik(massiv) {
//     let yigindi = massiv.reduce(function(akkumulyator, son) {
//         return akkumulyator + son;
//     }, 0);
//     return yigindi / massiv.length;
// }

// let sonlarMassivi = [3, 5, 7, 2, 4];

// let ortacha = ortachaArifmetik(sonlarMassivi);
// console.log("O'rtacha arifmetik qiymat: " + ortacha);



// // 7
// function kopaytmaHisobla(massiv) {
//     return massiv.reduce(function(akkumulyator, son) {
//         return akkumulyator * son;
//     }, 1);
// }

// let sonlarMassivi = [3, 5, 7, 2, 4];

// let kopaytma = kopaytmaHisobla(sonlarMassivi);
// console.log("Sonlarning ko'paytmasi: " + kopaytma);



// // 8
// function toqSonlarOrtacha(massiv) {
//     let toqSonlar = massiv.filter(function(son) {
//         return son % 2 !== 0;
//     });

//     if (toqSonlar.length === 0) {
//         return null; 
//     }

//     let yigindi = toqSonlar.reduce(function(akkumulyator, son) {
//         return akkumulyator + son;
//     }, 0);
    
//     return yigindi / toqSonlar.length;
// }

// let sonlarMassivi = [3, 5, 7, 2, 4, 10, 15];

// let ortacha = toqSonlarOrtacha(sonlarMassivi);
// console.log("Toq sonlarning o'rtacha arifmetik qiymati: " + ortacha);

